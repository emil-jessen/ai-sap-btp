sap.ui.define(["sap/ui/core/mvc/Controller"],function(e){"use strict";return e.extend("my.btp.app.ui.controller.NotFound",{})});
//# sourceMappingURL=NotFound.controller.js.map